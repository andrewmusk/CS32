#include "provided.h"
#include <string>
#include <vector>
#include <queue>
#include "MyMap.h"
#include "support.h"
using namespace std;

class NavigatorImpl
{
public:
    NavigatorImpl();
    ~NavigatorImpl();
    bool loadMapData(string mapFile);
    NavResult navigate(string start, string end, vector<NavSegment>& directions) const;
private:
    AttractionMapper m_attrMap;
    SegmentMapper m_segMap;
    string getStreetName(newGeoCoord first, newGeoCoord second) const;
    bool nextIsTurn(newGeoCoord first, newGeoCoord second, newGeoCoord third) const;
    string getDirectionForTurn(newGeoCoord g1, newGeoCoord g2, newGeoCoord g3) const;
};

NavigatorImpl::NavigatorImpl()
{
}

NavigatorImpl::~NavigatorImpl()
{
}

bool NavigatorImpl::loadMapData(string mapFile)
{
    MapLoader ml;
    if(!ml.load(mapFile))
    {
        return false;
    }
    m_attrMap.init(ml);
    m_segMap.init(ml);
    
    return true;  // This compiles, but may not be correct
}

NavResult NavigatorImpl::navigate(string start, string end, vector<NavSegment> &directions) const
{
    MyMap<newGeoCoord,newGeoCoord> routeLinks;
    priority_queue<Node> routes;
    newGeoCoord c_start;
    newGeoCoord c_end;
    
    m_attrMap.getGeoCoord(start, c_start.m_coord);
    m_attrMap.getGeoCoord(end, c_end.m_coord);
    
    cout << "THE END COORD IS :" << c_end.m_coord.latitudeText << " " << c_end.m_coord.longitudeText << endl;
    
    vector<StreetSegment>  startStreet = m_segMap.getSegments(c_start.m_coord);
    vector<StreetSegment> endStreet = m_segMap.getSegments(c_end.m_coord);
    
    Node startNode(start,c_start.m_coord,c_end.m_coord,nullptr);
    routes.push(startNode);
    
    if(startStreet.size()==0)
    {
        return NAV_BAD_SOURCE;
    }
    if(endStreet.size()==0)
    {
        return NAV_BAD_DESTINATION;
    }
//    for(int i =0 ; i < startStreet.size(); i++)
//    {
//        GeoCoord temp = startStreet[i].segment.start;
//        //newGeoCoord newCoord(temp.latitudeText,temp.longitudeText);
//        Node curNode(startStreet[i].streetName, temp,c_end.m_coord,nullptr);
//        routes.push(curNode);
//        routeLinks.associate(temp, c_start);
//        
//        temp = startStreet[i].segment.end;
//        //newGeoCoord newCoord2(temp.latitudeText,temp.longitudeText);
//        Node curNode2(startStreet[i].streetName,temp,c_end.m_coord,nullptr);
//        routes.push(curNode2);
//        routeLinks.associate(temp, c_start);
//    }
    
    bool found = false;
    
    while(!found)
    {
        cout << "The size is :" << routes.size() << endl;
        if(routes.empty())
        {
            return NAV_NO_ROUTE;
        }
        
        Node cur = routes.top();
        routes.pop();
        
        for(int i = 0; i<endStreet.size(); i++)
        {
            if((cur.m_cur.m_coord.latitude == endStreet[i].segment.end.latitude && cur.m_cur.m_coord.longitude == endStreet[i].segment.end.longitude)||(cur.m_cur.m_coord.latitude == endStreet[i].segment.start.latitude && cur.m_cur.m_coord.longitude == endStreet[i].segment.start.longitude))
            {
                routeLinks.associate(c_end, cur.m_cur);
                found = true;
                break;
            }
        }
       
        vector<StreetSegment>  curStreet = m_segMap.getSegments(cur.m_cur.m_coord);
        
        for(int i = 0; i < curStreet.size(); i++)
        {
            if(routeLinks.find(curStreet[i].segment.start) == nullptr)
            {
                Node startNode(curStreet[i].streetName, curStreet[i].segment.start, c_end.m_coord, &cur);
                routes.push(startNode);
                routeLinks.associate(curStreet[i].segment.start, cur.m_cur);
            }
            if(routeLinks.find(curStreet[i].segment.end) == nullptr)
            {
                Node endNode(curStreet[i].streetName, curStreet[i].segment.end, c_end.m_coord, &cur);
                routes.push(endNode);
                routeLinks.associate(curStreet[i].segment.end, cur.m_cur);
            }
        }
    }
    
    vector<newGeoCoord> routeTrace;
    newGeoCoord cur = c_end;
    routeTrace.push_back(c_end);
    
    while(!(cur.m_coord.latitude == c_start.m_coord.latitude && cur.m_coord.longitude == c_start.m_coord.longitude))
    {
        const newGeoCoord* value = routeLinks.find(cur);
        routeTrace.push_back(*value);
        cur = *value;
    }
    cout << "THe last three are: " << endl << routeTrace[2].m_coord.latitudeText << " " << routeTrace[2].m_coord.longitudeText << endl << routeTrace[1].m_coord.latitudeText << " " << routeTrace[1].m_coord.longitudeText << endl;

    cout << routeTrace[0].m_coord.latitudeText << " " << routeTrace[0].m_coord.longitudeText << endl;
    
    
    while(directions.size()!=0)
    {
        directions.erase(directions.begin());
    }
    cout << routeTrace.size() << endl;
    for(int k = routeTrace.size()-1; k>=0 ; k--)
    {
        string direction;
        string name;
        if(k>=1)
        {
            string name = getStreetName(routeTrace[k],routeTrace[k-1]);
            double distance = distanceEarthMiles(routeTrace[k].m_coord,routeTrace[k-1].m_coord);
            GeoSegment curSeg(routeTrace[k].m_coord,routeTrace[k-1].m_coord);
            
            direction = getDirection(routeTrace[k], routeTrace[k-1]);
            NavSegment c_direction(direction,name,distance,curSeg);
            directions.push_back(c_direction);
        }
        
        
        if(k>=2)
        {
            bool isTurn = nextIsTurn(routeTrace[k], routeTrace[k-1], routeTrace[k-2]);
            if(isTurn)
            {
                direction = getDirectionForTurn(routeTrace[k], routeTrace[k-1], routeTrace[k-2]);
                name = getStreetName(routeTrace[k-1], routeTrace[k-2]);
                NavSegment c_direction(direction,name);
                directions.push_back(c_direction);
            }
        }
    }
    return NAV_SUCCESS;
}





string NavigatorImpl::getStreetName(newGeoCoord first, newGeoCoord second) const
{
    vector<StreetSegment> one = m_segMap.getSegments(first.m_coord);
    vector<StreetSegment> two = m_segMap.getSegments(second.m_coord);
    for (int k = 0; k < one.size(); k++)
    {
        for (int i = 0; i < two.size(); i++)
        {
            if (one[k].streetName == two[i].streetName)
                return one[k].streetName;
        }
    }
    return "name not found for street";
}

bool NavigatorImpl::nextIsTurn(newGeoCoord first, newGeoCoord second, newGeoCoord third) const
{
    if (getStreetName(first, second) == getStreetName(second, third))
        return false;
    return true;
}


string NavigatorImpl::getDirectionForTurn(newGeoCoord g1, newGeoCoord g2, newGeoCoord g3) const
{
    string dir;
    // make 2 geosegments
    GeoSegment geo1(g1.m_coord, g2.m_coord);
    GeoSegment geo2(g2.m_coord, g3.m_coord);
    
    // pass into 2 lines
    double angle;
    angle = angleBetween2Lines(geo1, geo2);
    
    // give it it's direction
    if(angle >=0 && angle<=180)
    {
        dir = "left";
    }
    if(angle >=  180 && angle <=360)
    {
        dir = "right";
    }
    
    return dir;
}


//******************** Navigator functions ************************************

// These functions simply delegate to NavigatorImpl's functions.
// You probably don't want to change any of this code.

Navigator::Navigator()
{
    m_impl = new NavigatorImpl;
}

Navigator::~Navigator()
{
    delete m_impl;
}

bool Navigator::loadMapData(string mapFile)
{
    return m_impl->loadMapData(mapFile);
}

NavResult Navigator::navigate(string start, string end, vector<NavSegment>& directions) const
{
    return m_impl->navigate(start, end, directions);
}
