#include "provided.h"
#include <string>
#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

class MapLoaderImpl
{
public:
	MapLoaderImpl();
	~MapLoaderImpl();
	bool load(string mapFile);
	size_t getNumSegments() const;
	bool getSegment(size_t segNum, StreetSegment& seg) const;
private:
    vector<StreetSegment> m_segments;
};

MapLoaderImpl::MapLoaderImpl()
{
}

MapLoaderImpl::~MapLoaderImpl()
{
}

bool MapLoaderImpl::load(string mapFile)
{
    ifstream infile(mapFile);    // infile is a name of our choosing
    if ( ! infile )		        // Did opening the file fail?
    {
        cerr << "Error: Cannot open data.txt!" << endl;
        return false;
    }
    
    std::string streetName;
    while (getline(infile, streetName))
    {
        StreetSegment seg;
        string lat1, lat2, lon1, lon2, trash;
        
        getline(infile,lat1,',');
        char c;
        infile.get(c);
        if(c != ' ')
        {
            getline(infile,lon1,' ');
            lon1 = c+ lon1;
 
        }
        else
        {
            getline(infile,lon1,' ');
        }
        
        getline(infile,lat2,',');
        char j;
        infile.get(j);
        if(j != ' ')
        {
            getline(infile,lon2,'\n');
            lon2 = j + lon2;
            
        }
        else
        {
            getline(infile,lon2,'\n');
        }
        
        GeoCoord c_start(lat1,lon1);
        GeoCoord c_end(lat2,lon2);
        GeoSegment c_seg = GeoSegment(c_start,c_end);
        
        int count;
        infile >> count;
        // If you want to consume and ignore the rest of the line the
        // number is found on, follow this with
        infile.ignore(10000, '\n');
        
        vector<Attraction> attracts;
        for(int j =0; j<count; j++)
        {
            string name, lat, lon;
            getline(infile,name,'|');
            getline(infile,lat,',');
            
            char k;
            infile.get(k);
            if(k != ' ')
            {
                getline(infile,lon,'\n');
                lon = k + lon;
                
            }
            else
            {
                getline(infile,lon,'\n');
            }
            GeoCoord c_coord = GeoCoord(lat, lon);
            Attraction attr;
            attr.name = name;
            attr.geocoordinates = c_coord;
            attracts.push_back(attr);
        }
        seg.streetName = streetName;
        seg.attractions=attracts;
        seg.segment = c_seg;
        
        m_segments.push_back(seg);
    }
    
    return true;
}

size_t MapLoaderImpl::getNumSegments() const
{
    return m_segments.size();
}

bool MapLoaderImpl::getSegment(size_t segNum, StreetSegment &seg) const
{
    if(segNum > m_segments.size()-1)
    {
        return false;
    }
    seg = m_segments[segNum];
    return true;
}

//******************** MapLoader functions ************************************

// These functions simply delegate to MapLoaderImpl's functions.
// You probably don't want to change any of this code.

MapLoader::MapLoader()
{
	m_impl = new MapLoaderImpl;
}

MapLoader::~MapLoader()
{
	delete m_impl;
}

bool MapLoader::load(string mapFile)
{
	return m_impl->load(mapFile);
}

size_t MapLoader::getNumSegments() const
{
	return m_impl->getNumSegments();
}

bool MapLoader::getSegment(size_t segNum, StreetSegment& seg) const
{
   return m_impl->getSegment(segNum, seg);
}
